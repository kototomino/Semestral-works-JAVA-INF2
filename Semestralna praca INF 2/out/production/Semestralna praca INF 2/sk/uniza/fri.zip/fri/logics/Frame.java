package sk.uniza.fri.logics;

import javax.swing.JFrame;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class Frame extends JFrame {

    public Frame() {
        super("FlappyBird");
        this.setResizable(false);
        this.setBounds(350, 30, 800, 800);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public Frame(String type) {
        super("Menu");
        if (type.equals("menu")) {
            this.setResizable(false);
            this.setSize(900, 350);
            this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        }
    }
}
