package sk.uniza.fri.modes;

import java.awt.Color;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class Hard extends Modes {
    public Hard() {
        super(12, new Color(0, 0, 0), new Color(90, 3, 3), new Color(38, 51, 138), new Color(3, 74, 29), new Color(152, 73, 13) );
    }
    public int getSpeed() {
        return super.getSpeed();
    }
    public Color getTubesColor() {
        return super.getTubesColor();
    }
    public Color getCloudsColor() {
        return super.getCloudsColor();
    }



    @Override
    public Color getBackgroundColor() {
        return super.getBackgroundColor();
    }

    @Override
    public Color getGrassColor() {
        return super.getGrassColor();
    }

    @Override
    public Color getGroundColor() {
        return super.getGroundColor();
    }
}
