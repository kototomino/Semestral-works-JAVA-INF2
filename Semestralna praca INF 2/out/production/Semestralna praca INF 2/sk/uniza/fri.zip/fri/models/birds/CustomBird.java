package sk.uniza.fri.models.birds;

import sk.uniza.fri.tools.Animations;
import sk.uniza.fri.tools.Buffer;
import sk.uniza.fri.tools.IJumpAnimations;

import java.awt.image.BufferedImage;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class CustomBird extends Bird implements IJumpAnimations {
    private final Animations discoJump;
    public CustomBird() {
        super();
        this.discoJump = new Animations(-500);


        this.discoJump.addImage(Buffer.getImage("images/yellowbird-downflap.png"));
        this.discoJump.addImage(Buffer.getImage("images/yellowbird-midflap.png"));
        this.discoJump.addImage(Buffer.getImage("images/yellowbird-upflap.png"));

        this.discoJump.addImage(Buffer.getImage("images/bluebird-downflap.png"));
        this.discoJump.addImage(Buffer.getImage("images/bluebird-midflap.png"));
        this.discoJump.addImage(Buffer.getImage("images/bluebird-upflap.png"));

        this.discoJump.addImage(Buffer.getImage("images/redbird-downflap.png"));
        this.discoJump.addImage(Buffer.getImage("images/redbird-midflap.png"));
        this.discoJump.addImage(Buffer.getImage("images/redbird-upflap.png"));
    }

    @Override
    public BufferedImage getJumpImages() {
        return this.discoJump.getImage();
    }

    @Override
    public void updateJumps() {
        this.discoJump.update();

    }

    @Override
    public int getWidth() {
        return super.getWidth();
    }

    @Override
    public int getHeight() {
        return super.getHeight();
    }

    @Override
    public int getX() {
        return super.getX();
    }

    @Override
    public int getY() {
        return super.getY();
    }
}
