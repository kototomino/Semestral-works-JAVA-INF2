package sk.uniza.fri.modes;

import java.awt.Color;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class Medium extends Modes {
    public Medium() {
        super(7, new Color(205, 198, 19, 255), new Color(81, 128, 127), new Color(10, 202, 157), new Color(151, 202, 10, 255), new Color(174, 126, 43));
    }

    @Override
    public Color getBackgroundColor() {
        return super.getBackgroundColor();
    }

    @Override
    public Color getGrassColor() {
        return super.getGrassColor();
    }

    @Override
    public Color getGroundColor() {
        return super.getGroundColor();
    }

    public int getSpeed() {
        return super.getSpeed();
    }
    public Color getTubesColor() {
        return super.getTubesColor();
    }
    public Color getCloudsColor() {
        return super.getCloudsColor();
    }
}
