package sk.uniza.fri.modes;

import java.awt.Color;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class Easy extends Modes {
    public Easy () {
        super(5, new Color(0, 111, 7), Color.WHITE, new Color(0, 188, 255), new Color(10, 156, 10), Color.ORANGE );
    }
    public int getSpeed() {
        return super.getSpeed();
    }
    public Color getTubesColor() {
        return super.getTubesColor();
    }
    public Color getCloudsColor() {
        return super.getCloudsColor();
    }

    @Override
    public Color getBackgroundColor() {
        return super.getBackgroundColor();
    }

    @Override
    public Color getGrassColor() {
        return super.getGrassColor();
    }

    @Override
    public Color getGroundColor() {
        return super.getGroundColor();
    }
}
