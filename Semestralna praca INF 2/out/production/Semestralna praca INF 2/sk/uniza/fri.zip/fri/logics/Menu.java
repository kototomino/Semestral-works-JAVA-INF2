package sk.uniza.fri.logics;



import sk.uniza.fri.modes.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;


/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
@SuppressWarnings("MagicConstant")
public class Menu {


    public Menu() {
        JFrame start = new JFrame("Welcome to the Game !!!");
        ImageIcon startImage = new ImageIcon("images\\start.jpg");
        JLabel startLabel = new JLabel(startImage);
        start.setBounds(400, 100, 728, 450);
        start.setResizable(false);
        start.add(startLabel);
        start.setVisible(true);
        start.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        JOptionPane.showMessageDialog(null, "WELCOME TO THE GAME :)\nCHOOSE A MODE U WANT TO SHRED!\nCREATED BY : TOMAS KOTRIK");
        start.dispose();

        JFrame menu = new Frame("menu");

        GridLayout layout = new GridLayout(1, 3);
        menu.setLayout(layout);

        ImageIcon iconEasy = new ImageIcon("images\\easy.png");
        ImageIcon iconMedium = new ImageIcon("images\\medium.png");
        ImageIcon iconHard = new ImageIcon("images\\hard.png");

        JButton buttonEasy = new JButton("EASY", iconEasy);
        buttonEasy.setHorizontalTextPosition(SwingConstants.CENTER);
        buttonEasy.setFont(new Font(Font.MONOSPACED, 25, 50));
        buttonEasy.setForeground(Color.WHITE);

        JButton buttonMedium = new JButton("MEDIUM", iconMedium);
        buttonMedium.setHorizontalTextPosition(SwingConstants.CENTER);
        buttonMedium.setFont(new Font(Font.MONOSPACED, 25, 50));
        buttonMedium.setForeground(Color.WHITE);

        JButton buttonHard = new JButton("HARD", iconHard);
        buttonHard.setHorizontalTextPosition(SwingConstants.CENTER);
        buttonHard.setFont(new Font(Font.MONOSPACED, 25, 50));
        buttonHard.setForeground(Color.WHITE);

        JButton buttonCustom = new JButton("@CREDITS@");
        buttonCustom.setHorizontalTextPosition(SwingConstants.CENTER);
        buttonCustom.setFont(new Font(Font.MONOSPACED, 25, 50));
        buttonCustom.setForeground(Color.WHITE);




        menu.add(buttonEasy);
        menu.add(buttonMedium);
        menu.add(buttonHard);
        menu.add(buttonCustom);
        menu.setVisible(true);
        menu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        menu.setResizable(false);

        buttonEasy.addActionListener(e -> {

            Modes easy = new Easy();
            sk.uniza.fri.logics.Frame frame = new sk.uniza.fri.logics.Frame();
            Game game = new Game(easy.getSpeed(), easy.getTubesColor(), easy.getCloudsColor(), easy.getBackgroundColor(), easy.getGrassColor(), easy.getGroundColor(), "easy");
            frame.add(game);
            frame.setVisible(true);
            menu.setVisible(false);


        });

        buttonMedium.addActionListener(e -> {
            Modes medium = new Medium();
            sk.uniza.fri.logics.Frame frame = new sk.uniza.fri.logics.Frame();
            Game game = new Game(medium.getSpeed(), medium.getTubesColor(), medium.getCloudsColor(), medium.getBackgroundColor(), medium.getGrassColor(), medium.getGroundColor(), "medium");
            frame.add(game);
            frame.setVisible(true);
            menu.setVisible(false);


        });

        buttonHard.addActionListener(e -> {
            Modes hard = new Hard();
            Frame frame = new Frame();
            Game game = new Game(hard.getSpeed(), hard.getTubesColor(), hard.getCloudsColor(), hard.getBackgroundColor(), hard.getGrassColor(), hard.getGroundColor(), "hard");
            frame.add(game);
            frame.setVisible(true);
            menu.setVisible(false);

        });

        buttonCustom.addActionListener(e -> {
            Modes custom = new Custom();
            Frame frame = new Frame();
            Game game = new Game(custom.getSpeed(), custom.getTubesColor(), custom.getCloudsColor(), custom.getBackgroundColor(), custom.getGrassColor(), custom.getGroundColor(), "custom");

            frame.add(game);
            frame.setVisible(true);
            menu.setVisible(false);




        });
    }




}
