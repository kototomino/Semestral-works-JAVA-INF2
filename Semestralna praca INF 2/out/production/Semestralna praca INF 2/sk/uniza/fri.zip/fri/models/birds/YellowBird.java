package sk.uniza.fri.models.birds;

import sk.uniza.fri.tools.Animations;
import sk.uniza.fri.tools.Buffer;
import sk.uniza.fri.tools.IJumpAnimations;

import java.awt.image.BufferedImage;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class YellowBird extends Bird implements IJumpAnimations {
    private final Animations yellowJump;

    public YellowBird() {
        super();

        this.yellowJump = new Animations(85);

        this.yellowJump.addImage(Buffer.getImage("images/yellowbird-downflap.png"));
        this.yellowJump.addImage(Buffer.getImage("images/yellowbird-midflap.png"));
        this.yellowJump.addImage(Buffer.getImage("images/yellowbird-upflap.png"));
    }

    @Override
    public int getWidth() {
        return super.getWidth();
    }

    @Override
    public int getHeight() {
        return super.getHeight();
    }

    @Override
    public int getX() {
        return super.getX();
    }

    @Override
    public int getY() {
        return super.getY();
    }

    @Override
    public BufferedImage getJumpImages() {
        return this.yellowJump.getImage();
    }

    @Override
    public void updateJumps() {
        this.yellowJump.update();

    }
}
