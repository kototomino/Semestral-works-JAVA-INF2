package sk.uniza.fri.modes;

import javax.swing.JOptionPane;
import java.awt.Color;
import java.util.Random;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class Custom extends Modes {



    public Custom () {




        super(Integer.parseInt(JOptionPane.showInputDialog(null, "5-20", "CHOOSE YOUR SPEED", JOptionPane.QUESTION_MESSAGE)),
                Color.getColor(JOptionPane.showInputDialog(null, "RED\nBLUE\nYELLOW", "CHOOSE BIRD'S COLOR", JOptionPane.QUESTION_MESSAGE)),
                Color.getColor(JOptionPane.showInputDialog(null, "RED\nBLUE\nYELLOW", "CHOOSE BIRD'S COLOR", JOptionPane.QUESTION_MESSAGE)),
                Color.getColor(JOptionPane.showInputDialog(null, "RED\nBLUE\nYELLOW", "CHOOSE BIRD'S COLOR", JOptionPane.QUESTION_MESSAGE)),
                Color.getColor(JOptionPane.showInputDialog(null, "RED\nBLUE\nYELLOW", "CHOOSE BIRD'S COLOR", JOptionPane.QUESTION_MESSAGE)),
                Color.getColor(JOptionPane.showInputDialog(null, "RED\nBLUE\nYELLOW", "CHOOSE BIRD'S COLOR", JOptionPane.QUESTION_MESSAGE)));

    }

    @Override
    public Color getBackgroundColor() {
        return super.getBackgroundColor();
    }

    @Override
    public Color getGrassColor() {
        return super.getGrassColor();
    }

    @Override
    public Color getGroundColor() {
        return super.getGroundColor();
    }

    @Override
    public Color getTubesColor() {
        return super.getTubesColor();
    }

    @Override
    public Color getCloudsColor() {
        return super.getCloudsColor();
    }

    @Override
    public int getSpeed() {
        return super.getSpeed();
    }
}
