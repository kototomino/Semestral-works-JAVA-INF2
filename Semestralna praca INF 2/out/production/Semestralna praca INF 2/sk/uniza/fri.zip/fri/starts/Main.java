package sk.uniza.fri.starts;


import sk.uniza.fri.logics.Menu;

/**
 * Created by IntelliJ IDEA.
 * User: ASUS-PC
 * Date: 29/03/2021
 * Time: 6:15 pm
 */
public class Main {

    public static void main(String[] args) {
        new Menu();

        String filepath = "music\\music.wav";
        Music music = new Music();
        music.playMusic(filepath);




    }



}
