package sk.uniza.fri.models.birds;

import sk.uniza.fri.tools.Animations;
import sk.uniza.fri.tools.Buffer;
import sk.uniza.fri.tools.IJumpAnimations;

import java.awt.image.BufferedImage;

/**
 * 29/03/2021 - 6:15 pm
 *
 * @author ASUS-PC
 */
public class BlueBird extends Bird implements IJumpAnimations {
    private final Animations blueJump;

    public BlueBird() {
        super();

        this.blueJump = new Animations(85);

        this.blueJump.addImage(Buffer.getImage("images/bluebird-downflap.png"));
        this.blueJump.addImage(Buffer.getImage("images/bluebird-midflap.png"));
        this.blueJump.addImage(Buffer.getImage("images/bluebird-upflap.png"));
    }

    @Override
    public int getWidth() {
        return super.getWidth();
    }

    @Override
    public int getHeight() {
        return super.getHeight();
    }

    @Override
    public int getX() {
        return super.getX();
    }

    @Override
    public int getY() {
        return super.getY();
    }

    @Override
    public BufferedImage getJumpImages() {
        return this.blueJump.getImage();
    }

    @Override
    public void updateJumps() {
        this.blueJump.update();

    }
}
